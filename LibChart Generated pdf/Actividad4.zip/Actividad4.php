<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?PHP
    $link = mysqli_connect("localhost", "root", "");
    mysqli_select_db($link, "votaciones");
    $result = mysqli_query($link, "SELECT Nombre, id_votante FROM votantes");
    ?>

    <form action="Actividad4B.php" method="post">

        <p>
        Introduce tu nombre: 


        <select name="id_votante">
        <?php while ($row = mysqli_fetch_array($result)) { ?>

            
            <option name="nombre" value=<?php echo $row["id_votante"] ?>> <?php echo $row['Nombre'] ?> </option>
            
        <?php } ?>
        </select>
        

        <?php
            mysqli_free_result($result);
            mysqli_close($link);
        ?>
        </p>


        <p><input type="radio" name="partido" value="PRI" />PRI
            <input type="radio" name="partido" value="PAN" />PAN
            <input type="radio" name="partido" value="PRD" />PRD
            <input type="radio" name="partido" value="MORENA" />MORENA
            <input type="radio" name="partido" value="Nulo" />Anular voto
        </p>
        <p><input type="submit" /></p>

        
    </form>
    <img src="generated/graficaPartidos.png">   
    
</body>

</html>